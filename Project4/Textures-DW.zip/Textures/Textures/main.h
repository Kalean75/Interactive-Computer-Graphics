#pragma once

void setMesh();
void initObject(bool load);
void initMatrices();
