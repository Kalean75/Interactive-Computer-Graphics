#pragma once

void initMatrices();
void initRenderBuffers();
void updateLight();
void initializeTextures(std::string normName);
void initBuffers();
void setshaders();
int DEG2RAD(int degrees);
int RAD2DEG(float radians);