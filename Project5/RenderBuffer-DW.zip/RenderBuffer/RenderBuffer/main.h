#pragma once
void setMesh();
void initObject(char* file, bool load);
void initMatrices();
void initPlane();
void initRenderBuffer();